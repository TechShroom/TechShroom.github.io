package k.greenfoot3d.ui;

import javax.swing.JOptionPane;

public class Inform {

	public static void userOf(String msg) {
		JOptionPane.showMessageDialog(null, msg);
	}

}
