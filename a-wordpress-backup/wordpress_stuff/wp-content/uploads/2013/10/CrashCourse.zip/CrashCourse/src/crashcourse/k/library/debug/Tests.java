package crashcourse.k.library.debug;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JFileChooser;

import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.Display;

import crashcourse.k.library.lwjgl.DisplayLayer;
import crashcourse.k.library.lwjgl.control.Keys;
import crashcourse.k.library.lwjgl.control.MouseHelp;
import crashcourse.k.library.lwjgl.tex.ColorTexture;
import crashcourse.k.library.lwjgl.tex.Texture;
import crashcourse.k.library.main.KMain;
import crashcourse.k.library.util.WUtils;

public class Tests extends KMain {

	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		DisplayLayer.initDisplay(false, 800, 500, "Testing CrashCourse", true,
				args);
		while (!Display.isCloseRequested()) {
			DisplayLayer.loop(120);
		}
		DisplayLayer.destroy();
		System.exit(0);
	}

	@Override
	public void onDisplayUpdate(int delta) {
		if (Keys.keyWasReleased(Keyboard.KEY_ESCAPE)) {
			DisplayLayer.toggleFull();
		}
	}

	@Override
	public void init(String[] args) {
		try {
			WUtils.windows_safe_JFC(new JFileChooser(),
					JFileChooser.OPEN_DIALOG);
			Texture texture = new ColorTexture(Color.red, new Dimension(10, 10));
			MouseHelp.createFollowCursor(texture, 10, 10, 0,
					texture.dim.height - 1);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
